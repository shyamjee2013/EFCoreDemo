﻿
using EFCoreDemo.Repository;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace EFCoreDemo
{
    public class BaseClass
    {
        
        
    }
}
