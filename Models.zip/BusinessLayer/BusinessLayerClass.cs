﻿using EFCoreDemo.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EFCoreDemo.BusinessLayer
{
    public class BusinessLayerClass
    {
        //private ICategoryTblRepository _categoryTblRepository;
        //public BusinessLayerClass(CategoryTblRepository categoryTblRepository)
        //{
        //    _categoryTblRepository = categoryTblRepository;
        //}
        public void BusinessLayerMethod()
        {
           // var result = _categoryTblRepository.GetAllCategory().ToList();
        }
    }
}
