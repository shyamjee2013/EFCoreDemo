﻿using EFCoreDemo.Models;
using EFCoreDemo.Repository;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace EFCoreDemo
{
    public class UseService : BaseClass
    {

        private readonly ICategoryTblRepository _repo;
        public UseService(ICategoryTblRepository iCategoryTblRepository)
        {
            _repo = iCategoryTblRepository;
        }
        public void Run()
        {            
            _repo.GetAllCategory();
            
        }
    }
}
