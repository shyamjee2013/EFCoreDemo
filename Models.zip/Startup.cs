﻿using EFCoreDemo.Models;
using EFCoreDemo.Repository;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace EFCoreDemo
{
    public class Startup
    {
        public static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddTransient<ICategoryTblRepository, CategoryTblRepository>();
            services.AddDbContext<SwiggyContext>();
            // Register application start point/Entry point. Thsi is very importent
            services.AddTransient<UseService>();
            return services;
        }
    }
}
