﻿using EFCoreDemo.Models;
using System.Collections.Generic;
using System.Linq;

namespace EFCoreDemo.Repository
{
    public class SubCategoryTblRepository : ISubCategoryTblRepository
    {
        public List<SubCategoryTbl> GetAllCategory()
        {
            List<SubCategoryTbl> result;
            using (SwiggyContext swiggyContext = new SwiggyContext())
            {
                result = swiggyContext.SubCategoryTbl.ToList();
            }
            return result;
        }
    }
}
