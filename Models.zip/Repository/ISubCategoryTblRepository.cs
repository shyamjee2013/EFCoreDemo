﻿using EFCoreDemo.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace EFCoreDemo.Repository
{
    public interface ISubCategoryTblRepository
    {
        List<SubCategoryTbl> GetAllCategory();
    }
}
