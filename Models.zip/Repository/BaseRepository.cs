﻿using EFCoreDemo.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace EFCoreDemo.Repository
{
    public class BaseRepository
    {
        public SwiggyContext _db;
    }
}
