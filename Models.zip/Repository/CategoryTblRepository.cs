﻿using EFCoreDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EFCoreDemo.Repository
{
    public class CategoryTblRepository : BaseRepository, ICategoryTblRepository
    {
        SwiggyContext _swiggyContext;
        public CategoryTblRepository()
        {
            _swiggyContext = new SwiggyContext();
        }

        public List<CategoryTbl> GetAllCategory()
        {
            List<CategoryTbl> result;
            result = _swiggyContext.CategoryTbl.ToList();

            //using base repositiry instance.
            result = _db.CategoryTbl.ToList();
           

            return result;
        }
    }
}
