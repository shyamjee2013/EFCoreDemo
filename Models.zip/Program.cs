﻿using EFCoreDemo.BusinessLayer;
using EFCoreDemo.Models;
using EFCoreDemo.Repository;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;

namespace EFCoreDemo
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Create service collection and configure our services (interfaces for DI)
            var services = Startup.ConfigureServices();
            
            // Generate a Service provideder provider.
            var serviceProvider = services.BuildServiceProvider();

            // Start your applciation ccode
            serviceProvider.GetService<UseService>().Run();
            
        }       
    }
}







//using EFCoreDemo.Models;
//using EFCoreDemo.Repository;
//using Microsoft.Extensions.DependencyInjection;
//using System;
//using System.Collections.Generic;

//namespace EFCoreDemo
//{
//    public class Program
//    {
//        private static ICategoryTblRepository _categoryTblRepository;
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Hello World!");

//            var services = new ServiceCollection();
//            ConfigureServices(services);

//            using (ServiceProvider serviceProvider = services.BuildServiceProvider())
//            {
//                _categoryTblRepository = serviceProvider.GetService<ICategoryTblRepository>();
//                List<CategoryTbl> result = _categoryTblRepository.GetAllCategory();

//                int i = 10;
//            }

//        }
//        private static void ConfigureServices(IServiceCollection services)
//        {
//            services.AddScoped<ICategoryTblRepository, CategoryTblRepository>();
//        }
//    }
//}
