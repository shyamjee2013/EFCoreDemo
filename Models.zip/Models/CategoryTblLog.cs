﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCoreDemo.Models
{
    [Table("CategoryTbl_Log")]
    public partial class CategoryTblLog
    {
        [StringLength(20)]
        public string Name { get; set; }
        [StringLength(20)]
        public string UpdatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? UpdatedDate { get; set; }
    }
}
