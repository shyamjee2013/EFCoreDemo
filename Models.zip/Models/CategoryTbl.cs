﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCoreDemo.Models
{
    public partial class CategoryTbl
    {
        public CategoryTbl()
        {
            SubCategoryTbl = new HashSet<SubCategoryTbl>();
        }

        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [InverseProperty("Category")]
        public virtual ICollection<SubCategoryTbl> SubCategoryTbl { get; set; }
    }
}
