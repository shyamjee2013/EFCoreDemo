﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCoreDemo.Models
{
    public partial class SubCategoryTbl
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(100)]
        public string SubCategoryName { get; set; }
        public int CategoryId { get; set; }

        [ForeignKey(nameof(CategoryId))]
        [InverseProperty(nameof(CategoryTbl.SubCategoryTbl))]
        public virtual CategoryTbl Category { get; set; }
    }
}
